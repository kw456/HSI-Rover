Example 2: Dual Motor Test
---------------------------
.. literalinclude:: ../examples/ex2_qwiic_scmd.py
    :caption: examples/ex2_qwiic_scmd.py
    :linenos: