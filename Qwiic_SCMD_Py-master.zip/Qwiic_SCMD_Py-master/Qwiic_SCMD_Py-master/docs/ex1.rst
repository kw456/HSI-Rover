Example 1: Single Motor Test
---------------------------
.. literalinclude:: ../examples/ex1_qwiic_scmd.py
    :caption: examples/ex1_qwiic_scmd.py
    :linenos: