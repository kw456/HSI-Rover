API Reference
==============

.. automodule:: qwiic_scmd
   :members:



