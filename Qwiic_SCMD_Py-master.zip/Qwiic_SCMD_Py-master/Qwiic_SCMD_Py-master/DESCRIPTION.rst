Qwiic Serial Control Motor Driver
====================================

This package provdes support for the SparkFun qwiic Serial Control Motor Driver breakout.